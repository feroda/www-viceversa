---
fullname: Riccardo Serafini
sub: "Senior Software Engineer <br>Unix System Administrator"
img: /images/team/riccardo_serafini.jpeg
facebook:
instagram:
linkedin:
---
