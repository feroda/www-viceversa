---
fullname: Luca Ferroni
sub: Founder
img: /images/team/luca_ferroni.jpeg
facebook:
instagram:
linkedin:
---
