---
fullname: Dawid Węglarz
sub: Backend Developer
img: /images/team/dawid_weglarz.jpeg
facebook:
instagram:
linkedin:
---
