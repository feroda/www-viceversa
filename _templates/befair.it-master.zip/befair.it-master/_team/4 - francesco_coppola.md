---
fullname: Francesco Coppola
sub: Frontend Developer
img: /images/team/francesco_coppola.jpg
facebook:
instagram:
linkedin:
---
