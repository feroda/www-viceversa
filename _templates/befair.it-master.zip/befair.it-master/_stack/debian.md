---
title: Debian
sub: Tutti i nostri server utilizzano Debian, questo ci garantisce una base solida e sempre aggiornata su cui costruire i nostri servizi Cloud, in linea con i principi Open.
background: /images/background-slider/debianbk.jpg
icon: /images/background-slider/debian.png
---
