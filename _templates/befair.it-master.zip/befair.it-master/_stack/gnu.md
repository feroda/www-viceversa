---
title: GNU/Linux
sub: Tutto il nostro lavoro di sviluppo poggia sulle solide basi della filosofia Open Source, del kernel Linux e dell'ecosistema GNU. Il modello Open è vincente e il mercato lo ha dimostrato. Costruire prodotti e servizi sulla base di software e librerie rilasciate con licenza libera assicura ai nostri clienti una qualità maggiore, maggiore sicurezza e trasparenza.
background: /images/background-slider/gnulinuxbk.jpg
icon: /images/background-slider/gnulinux.png
---
