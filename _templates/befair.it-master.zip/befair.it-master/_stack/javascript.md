---
title: JavaScript
sub: Fondamentale per lo sviluppo web. ECMAScript 6 ha risolto molti limiti e debolezze di questo linguaggio, e l'utilizzo di framework moderni come Vue, React, Angular ci permette di realizzare applicazioni web, anche molto complesse, senza compromettere la manutenibilità del codice.
background: /images/background-slider/jsbk.jpg
icon: /images/background-slider/js.png
---
