---
title: Flutter
sub: Questo framework moderno permette di sviluppare app native con un <i>look and feel</i> moderno ed accattivante, con una unica codebase. Questo ci permette di sviluppare applicazioni Android e iOS in tempi rapidi e di effettuare modifiche in maniera semplice.
background: /images/background-slider/flutterbk.jpg
icon: /images/background-slider/flutter.png
---
