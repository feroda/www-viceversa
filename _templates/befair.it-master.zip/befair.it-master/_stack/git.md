---
title: Git
sub: "È lo strumento con cui viene coordinato il più numeroso team di sviluppo della storia: quello del kernel Linux. Git è il sistema di versionamento standard per chi vuole rilasciare software di qualità. Unito ai potenti strumenti di collaborazione e organizzazione di Gitlab.com e Github.com diventa uno strumento potentissimo, che ci permette di tenere traccia di tutte le modifiche fatte al software ed integrare senza sforzo il contributo di ogni sviluppatore."
background: /images/background-slider/gitbk.jpg
icon: /images/background-slider/git.png
---
