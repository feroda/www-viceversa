---
title: Ansible
sub: Grazie a questo potente strumento di <b>Configuration Automation</b> non dobbiamo più eseguire lunghe procedure manuali per installare o aggiornare un software. Basta un click per preparare un nuovo server ad offrire servizi, escludendo l'errore umano e garantendo un ambiente coerente tra tutte le macchine che amministriamo.
background: /images/background-slider/ansbk.jpg
icon: /images/background-slider/ans.png
---
