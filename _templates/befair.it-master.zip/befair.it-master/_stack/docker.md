---
title: Docker
sub: '"sul mio PC funzionava" ormai è un ricordo! Rilasciamo il software in immagini Docker che includono tutte le dipendenze. In questo modo siamo veloci a pubblicare i progetti online e nuovi membri del team che si uniscono allo sviluppo possono iniziare a lavorare al codice in pochi minuti.'
background: /images/background-slider/dockerbk.jpg
icon: /images/background-slider/docker.png
---
