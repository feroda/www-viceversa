---
title: Python
sub: "Curva di apprendimento ripida, alto livello di astrazione, community consolidata e molto attiva, un'infinità di librerie a disposizione: queste caratteristiche rendono Python un linguaggio molto potente, non solo per lo sviluppo Web grazie a framework consolidati come Django, ma anche adatto ad applicazioni di Intelligenza Artificiale, Data Analysis e script sistemistici."
background: /images/background-slider/pythonbk.jpg
icon: /images/background-slider/python.png
---
