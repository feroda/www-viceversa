---
title: Django
sub: Il framework "per perfezionisti che devono rispettare le scadenze" ci permette di realizzare applicazioni web, API REST e interfacce CRUD in tempi molto rapidi, senza però trascurare la pulizia e la manutenibilità del codice.
background: /images/background-slider/djangobk.jpg
icon: /images/background-slider/django.png
---
